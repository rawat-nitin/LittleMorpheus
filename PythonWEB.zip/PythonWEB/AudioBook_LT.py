import os
import time
import playsound
import speech_recognition as sr
from gtts import gTTS

from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfdevice import PDFDevice

from pdfminer.pdfpage import PDFTextExtractionNotAllowed
from pdfminer.layout import LAParams, LTTextBox, LTTextLine
from pdfminer.converter import PDFPageAggregator

base_path = "/home/natalia/Desktop/KCGI/Semester 2nd/LeadershipTheory/AudioBook_LT/"

book = input("Type the name of book with extension : ")

my_file = os.path.join(base_path +"/"+ book)
log_file = os.path.join(base_path+"/"+"Story_Book.txt")

password = ""
extracted_text = ""

fp =open(my_file,"rb")

parser =PDFParser(fp)

document = PDFDocument(parser,password)

if not document.is_extractable:
    raise PDFTextExtractionNotAllowed
    
rsrcmgr = PDFResourceManager()

laparams = LAParams()

device = PDFPageAggregator(rsrcmgr, laparams=laparams)

interpreter = PDFPageInterpreter(rsrcmgr, device)


for page in PDFPage.create_pages(document):
	
	interpreter.process_page(page)
	
	layout = device.get_result()
	
	for lt_obj in layout:
		if isinstance(lt_obj, LTTextBox) or isinstance(lt_obj, LTTextLine):
			extracted_text += lt_obj.get_text()
			

fp.close()

			
with open(log_file, "wb") as my_log:
	my_log.write(extracted_text.encode("utf-8"))


str=open('/home/natalia/Desktop/KCGI/Semester 2nd/LeadershipTheory/AudioBook_LT/Story_Book.txt', 'r').read()


def speak(text):
    count = 0
    tts = gTTS(text=text, lang="en")
    filename =f'/home/natalia/Desktop/KCGI/Semester 2nd/LeadershipTheory/AudioBook_LT/AudioBook{count%2}.mp3'
    tts.save(filename)
    playsound.playsound(filename)
    save = input("Do you want to save Audiobook? (Type (Y or y)) : ")
    if (save == 'y')or (save == 'Y'):
        count += 1
        tts.save(f'/home/natalia/Desktop/KCGI/Semester 2nd/LeadershipTheory/AudioBook_LT/AudioBook{count%2}.mp3')  
        print("file is saved as mp3 format")
    else:
        return none;

    
    
play = input("Do you want to play Audiobook? (Type(Y or y)) : ")
if (play == 'y') or (play == 'Y'):
    speak(str)
else:
    print("Thank you for using Program..!!")    