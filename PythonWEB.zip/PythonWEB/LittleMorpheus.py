from flask import Flask
from flask import request
from flask import render_template
import playsound
import os
import time
import speech_recognition as sr
from gtts import gTTS


from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfdevice import PDFDevice

from pdfminer.pdfpage import PDFTextExtractionNotAllowed
from pdfminer.layout import LAParams, LTTextBox, LTTextLine
from pdfminer.converter import PDFPageAggregator


app = Flask(__name__)

@app.route('/')
def my_form():
    return render_template("my-form.html")

@app.route('/', methods=['POST'])
def my_form_post():
        
    bookName = request.form['bookname']
    
    if not bookName :
        return "<h1>not entered name</h1>"
    else :
        base_path = "/home/natalia/Desktop/Python/PythonWEB"
        my_file = os.path.join(base_path +"/"+ bookName)
        log_file = os.path.join(base_path+"/"+"Book_Name.txt")
        password = ""
        extracted_text = ""

        fp =open(my_file,"rb")
        parser =PDFParser(fp)

        document = PDFDocument(parser,password)
        rsrcmgr = PDFResourceManager()

        laparams = LAParams()

        device = PDFPageAggregator(rsrcmgr, laparams=laparams)

        interpreter = PDFPageInterpreter(rsrcmgr, device)
        for page in PDFPage.create_pages(document):
            interpreter.process_page(page)
            layout = device.get_result()
            
            for lt_obj in layout:
                if isinstance(lt_obj, LTTextBox) or isinstance(lt_obj, LTTextLine):
                    extracted_text += lt_obj.get_text()
        fp.close()
        
        with open(log_file, "wb") as my_log:
            my_log.write(extracted_text.encode("utf-8"))
            
        str=open('/home/natalia/Desktop/Python/PythonWEB/Book_Name.txt', 'r').read()
        tts = gTTS(text=str, lang="en")
        filename = "Audio.mp3"
        tts.save(filename)
        playsound.playsound(filename)
            
        

        return str
    
if __name__=='__main__':
    app.run()
    
    
    