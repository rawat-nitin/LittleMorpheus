function submit() {
    var x = document.getElementById('BookName').value;
    window.alert("Your Book's Name is : " +x );
}
